import React from "react";
import { Table } from "react-bootstrap";

function Movies() {
  const movies = [
    { name: "Movie 1", genre: "Action", releaseDate: "2024-03-10", rating: "8.5", price: "$10" },
    { name: "Movie 2", genre: "Comedy", releaseDate: "2024-04-15", rating: "7.9", price: "$12" },
  ];

  return (
    <div className="container mt-4">
      <h2>Now Showing</h2>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Movie Name</th>
            <th>Genre</th>
            <th>Release Date</th>
            <th>Ratings</th>
            <th>Ticket Price</th>
          </tr>
        </thead>
        <tbody>
          {movies.map((movie, index) => (
            <tr key={index}>
              <td>{movie.name}</td>
              <td>{movie.genre}</td>
              <td>{movie.releaseDate}</td>
              <td>{movie.rating}</td>
              <td>{movie.price}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
}

export default Movies;
