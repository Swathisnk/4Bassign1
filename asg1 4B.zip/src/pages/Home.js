import React from "react";

import CarouselComponent from "../components/CarouselComponent"; 
function Home() {
  return (
    <div>
      <CarouselComponent />
    </div>
  );
}

export default Home;
