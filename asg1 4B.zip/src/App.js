/*import React from 'react'
import{Container,Row,Col} from 'react-bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css';


export default function App() {
  return (
    <div>
      <Container >
        <Row>
          <Col className='bg-info'>col 1</Col>
          <Col className='bg-warning'>col 2</Col>
          <Col className='bg-danger'>col 3</Col>
          </Row>
      </Container>
      
      </div>
  )
}*/
 
import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import NavbarComponent from "./components/NavbarComponent";
import CarouselComponent from "./components/CarouselComponent";
import Home from "./pages/Home";
import Movies from "./pages/Movies";
import Footer from "./components/Footer";


function App() {
  return (
    <Router>
      <NavbarComponent />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/movies" element={<Movies />} />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;


